public class Number {
	private int content;

	public boolean equals(Number n) {
		if (content == n.content) {
			return true;
		}
		else {
			return false;
		}
	}
}