class TestInfiniteUnion {
    /*@
     @ requires true;
     @ ensures true;
     @ assignable (\infinite_union int x; \nothing);
     @*/
    public void testFunctionalStyle() {
        return;
    }


    /*@
     @ requires true;
     @ ensures true;
     @ assignable (\infinite_union int x; \nothing);
     @*/
    public void testFunctionalStyle() {
        return;
    }

}

