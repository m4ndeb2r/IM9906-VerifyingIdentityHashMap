example.name = Understanding Proof Situations
example.path = New Book/Using KeY
example.file = PostIncMod.java
example.additionalFile.1 = PostIncMod.java
example.additionalFile.2 = PostIncCorrected.java

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: 	PostInc.java
	PostIncCorrected.java
	PostIncMod.java

Wolfgang Ahrendt, Sarah Grebing
