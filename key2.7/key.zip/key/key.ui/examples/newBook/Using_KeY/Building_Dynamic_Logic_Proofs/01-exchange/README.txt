example.name = exchange.key
example.path = New Book/Using KeY/Building Dynamic Logic Proofs
example.file=exchange.key
example.additionalFile.1 = exchange.key

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.


Wolfgang Ahrendt, Sarah Grebing