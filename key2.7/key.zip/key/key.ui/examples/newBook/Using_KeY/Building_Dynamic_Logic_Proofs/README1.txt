example.name = Building Dynamic Logic Proofs - Calling Methods
example.path = New Book/Using KeY
example.additionalFile.1 = methodCall.key
example.additionalFile.2 = methodCall2.key
example.additionalFile.3 = methodExample/Person.java

This example folder consists the example files for the Chapter "Using KeY" in the KeY Book.

files: 
methodCall.key
methodCall2.key
Person.java

Wolfgang Ahrendt, Sarah Grebing
