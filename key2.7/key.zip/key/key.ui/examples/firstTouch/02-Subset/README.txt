example.name = Transitivity of Subset
example.path = Getting Started

Transitivity of Subset

This is a purely first-order predicate logic problem from the TPTP collection.
File     : SET027+3 : TPTP v2.5.0. Released v2.2.0.
Rating   : 0.25 (TPTP v5.5.0)

If X is a subset of Y and Y is a subset of Z, then X is a subset of Z.


