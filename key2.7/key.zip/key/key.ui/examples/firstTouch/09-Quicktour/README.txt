example.path = Getting Started
example.name = Quicktour
example.additionalFile.1 = paycard/CardException.java
example.additionalFile.2 = paycard/LogFile.java
example.additionalFile.3 = paycard/LogRecord.java
example.additionalFile.4 = paycard/PayCard.java
example.additionalFile.1 = paycard/CardException.java
example.exportFile.1 = gui/ChargeUI.java
example.exportFile.2 = gui/IssueCardUI.java
example.exportFile.3 = gui/Start.java

This is the PayCard example from the KeY-quicktour.

The quicktour for KeY 2.0 with information and explanations for KeY and this example 
can be found at http://www.key-project.org/download/quicktour/quicktour-2.0.zip.
