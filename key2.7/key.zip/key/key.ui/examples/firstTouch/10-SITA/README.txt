example.name = Search in Two Arrays
example.path = Getting Started
example.additionalFile.1 = SITA3.java


Search In Two Arrays algorithm as shown at the KeY tutorials in the RS3 project and at CADE 2013.

Class SITA3 keeps two arrays of integers. Three methods are declared: Method commonEntry(l,r) returns the smallest index between l and r such that both have the same entry. Method swap(a,pos1,pos2) swaps the entries a[pos1] and a[pos2]. Method rearrange() changes the two arrays such that all common entries are moved to the front. The specification so far does not state that rearrange() produces permutations.
