// package java.lang;

class System {
   public static final Writer out;
}

class Writer {
   public void println(int value);
}
