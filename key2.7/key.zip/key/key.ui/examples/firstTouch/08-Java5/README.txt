example.path = Getting Started
example.name = Java 5 Enhanced-for
example.additionalFile.1 = src/For.java

This example shows Java with an enhanced for loop (Java 5 +).
