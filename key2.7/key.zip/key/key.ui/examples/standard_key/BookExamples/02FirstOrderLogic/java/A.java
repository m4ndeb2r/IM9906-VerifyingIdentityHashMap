public interface A {
}
