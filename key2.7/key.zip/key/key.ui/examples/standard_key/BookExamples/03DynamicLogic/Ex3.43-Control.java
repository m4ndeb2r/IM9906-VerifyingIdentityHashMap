class Control {
  Data data;
}

class Data {
  int d;
}
