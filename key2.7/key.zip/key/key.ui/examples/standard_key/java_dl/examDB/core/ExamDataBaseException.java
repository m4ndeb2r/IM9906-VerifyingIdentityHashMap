package core;

public class ExamDataBaseException extends Exception{
    public ExamDataBaseException(String message) {
	super(message);
    }

    public ExamDataBaseException(){
    }
}
