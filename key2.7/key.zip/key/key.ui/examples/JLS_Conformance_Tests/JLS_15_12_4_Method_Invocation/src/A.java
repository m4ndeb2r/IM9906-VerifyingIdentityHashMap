public class A {

    
    public int m(int a, int b) {
	return a + b;
    }
    

}

class B extends A {

    public int m(int a, int b) {
	return a * b;
    }

}


