public class LList {

    public LList next;
    public int size;

}