public class Container {

    public int[] elements;

    public Object[] data;

}