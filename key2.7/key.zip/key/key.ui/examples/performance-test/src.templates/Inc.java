class Inc {
  int x;


  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_1 () {
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_2 () {
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_3 () {
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_4 () {
    x++;
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_5 () {
    x++;
    x++;
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_6 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_7 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_8 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
  }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_9 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
 }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_10 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
 }

  //@ requires x > 0;
  //@ ensures x > 0;
  void foo_20 () {
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
    x++;
  }

}
