example.path = Information Flow
example.name = Examples
example.additionalFile.1 = src/mini/AliasingExamples.java
example.additionalFile.2 = src/mini/MiniExamples.java
example.additionalFile.3 = src/mini/MiniExamplesLecture.java
example.additionalFile.4 = src/mini/DifferenceSeqLocset.java

Information flow examples.

A collection of several mini examples including the examples form the papers "Abstract Interpretation of Symbolic Execution with Explicit State Updates" and "A Theorem Proving Approach to Analysis of Secure Information Flow".

The information flow proof obligations of all secure examples can be proved fully automatically using the macro "Full Information Flow Auto Pilot".

