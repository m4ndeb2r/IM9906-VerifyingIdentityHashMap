This folder contains problems, that can be used to test external Prover.
Store new examples for SMT in this folder!
