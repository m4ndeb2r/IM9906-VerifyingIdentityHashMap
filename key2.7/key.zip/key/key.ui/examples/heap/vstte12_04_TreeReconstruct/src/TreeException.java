
class TreeException extends Exception {
}