example.name = Observer
example.path = Dynamic Frames
example.additionalFile.5 = ./src/Observer.java
example.additionalFile.1 = ./src/Subject.java
example.additionalFile.2 = ./src/ExampleObserver.java
example.additionalFile.3 = ./src/ExampleSubject.java
example.additionalFile.4 = ./src/ExampleClient.java


A version of the subject/observer design pattern.

All proof obligations are verifiable without user interaction. The proof for ExampleClient::m has about 250'000 nodes.
