example.name = Lists with Loop Contracts
example.path = Dynamic Frames/Block & Loop Contracts
example.additionalFile.1 = src/IntLinkedList.java
example.additionalFile.2 = src/IntList.java
example.additionalFile.3 = src/IntNode.java

This example demonstrates the use of loop contracts for operations on linked lists. It is heavily based on the "List with Sequences" example.


2018, Florian Lanzinger