class GSum {

  //@ ensures (\num_of Object o, p; false) == (\sum \real r; 0);
  void /*@ helper @*/ doNothing(){}
}
