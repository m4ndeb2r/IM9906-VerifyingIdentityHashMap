
public final class Node {
    public /*@nullable@*/ Node next;
    public Object data;
}
