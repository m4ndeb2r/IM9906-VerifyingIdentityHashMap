
//Non-Nullable version of list
public class ListNN {
 
 public ListNN next;  //non-null by default, according to JML's semantics
 public int value;


}