example.name = 4 - N Queens
example.path = Benchmarks/VSComp 10
example.additionalFile.1 = src/Queens.java

The fourth challenge from the Verified Software Competition (VSComp) at VSTTE'10, organised by Peter Mueller and Natarajan Shankar: 

Write a program to place N queens on an N x N chess board so that no queen can capture another one with a legal move.

Interactive proofs:
- search
