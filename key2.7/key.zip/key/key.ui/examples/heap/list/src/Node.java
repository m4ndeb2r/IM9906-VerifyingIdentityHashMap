public final class Node {
    public /*@nullable@*/ Node next;
    public /*@nullable@*/ Object data;
}
