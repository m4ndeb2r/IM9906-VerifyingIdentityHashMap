// A java file that is not parsable by KeY/recoder!
class Broken<T> {
    public <T> Function<T,T> get(T t) { return t -> t;}
}