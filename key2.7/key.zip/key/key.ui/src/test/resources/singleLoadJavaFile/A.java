class A {
    /*@ requires true; ensures true; assignable \nothing; */
    public /*helper*/ Broken doNothing() {

    }
}